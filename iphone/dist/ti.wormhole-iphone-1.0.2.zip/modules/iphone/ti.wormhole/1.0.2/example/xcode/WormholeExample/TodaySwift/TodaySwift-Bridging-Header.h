/**
 * Copyright (c) 2015 by Benjamin Bahrenburg. All Rights Reserved.
 * Licensed under the terms of the MIT License
 * Please see the LICENSE included with this distribution for details.
 *
 */

#ifndef WormholeExample_WormholeExample_TodaySwift_Bridging_Header_h
#define WormholeExample_WormholeExample_TodaySwift_Bridging_Header_h

#import "MMWormholeClient.h"

#endif
